"""JWT helpers for API auth."""
import logging
from datetime import datetime, timedelta, timezone

import jwt
from django.conf import settings
from django.http import JsonResponse
from api.models import User

logger = logging.getLogger(__name__)


def create_tokens(user):
    """Return access_token and refresh_token for user."""
    secret = settings.SECRET_KEY
    now = datetime.now(timezone.utc)
    sub = str(user.username) if user.username is not None else ""
    payload_access = {
        "sub": sub,
        "type": "access",
        "exp": now + timedelta(minutes=60),
    }
    payload_refresh = {
        "sub": sub,
        "type": "refresh",
        "exp": now + timedelta(days=7),
    }
    access_token = jwt.encode(payload_access, secret, algorithm="HS256")
    refresh_token = jwt.encode(payload_refresh, secret, algorithm="HS256")
    if hasattr(access_token, "decode"):
        access_token = access_token.decode("utf-8")
        refresh_token = refresh_token.decode("utf-8")
    return access_token, refresh_token


def get_user_from_request(request):
    """Get User from Authorization Bearer token or return None."""
    auth = (request.META.get("HTTP_AUTHORIZATION") or "").strip()
    parts = auth.split(None, 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    token = parts[1].strip()
    if not token:
        return None
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=["HS256"],
            leeway=60,
        )
        if payload.get("type") != "access":
            return None
        username = payload.get("sub")
        if username is None or username == "":
            return None
        if not isinstance(username, str):
            username = str(username)
        return User.objects.filter(username__iexact=username, is_active=True).first()
    except Exception:
        return None


def auth_required(view_func):
    """Decorator: return 401 JsonResponse if no valid user."""
    def wrapped(request, *args, **kwargs):
        try:
            user = get_user_from_request(request)
            if not user:
                return JsonResponse({"detail": "Authentication required"}, status=401)
            request.api_user = user
            return view_func(request, *args, **kwargs)
        except Exception as e:
            return JsonResponse({"detail": "Authentication or request failed", "error": str(e)}, status=500)
    return wrapped


def user_is_super_admin(user) -> bool:
    """True if user is platform super admin (tolerant of spacing/casing in role string)."""
    r = (getattr(user, "role", None) or "").strip().lower().replace(" ", "_").replace("-", "_")
    return r in ("super_admin", "superadmin")


def get_company_id(request):
    """
    Resolve company ID for tenant scoping.
    Super admin: use X-Selected-Company-Id if present, else user's company_id or first company.
    Other users: use user.company_id or first company.
    """
    from api.models import Company
    user = getattr(request, "api_user", None) or get_user_from_request(request)
    if not user:
        return None
    # Super admin can override via header
    if user_is_super_admin(user):
        header = request.META.get("HTTP_X_SELECTED_COMPANY_ID", "").strip()
        if header:
            try:
                cid = int(header)
                if Company.objects.filter(id=cid, is_deleted=False).exists():
                    return cid
            except (ValueError, TypeError):
                pass
            # Stale localStorage / deleted company: ignore header and fall through like no selection
    # Use user's company or first available
    if getattr(user, "company_id", None):
        if Company.objects.filter(id=user.company_id, is_deleted=False).exists():
            return user.company_id
    first = Company.objects.filter(is_deleted=False).order_by("id").first()
    if first:
        return first.id
    # No company: for super_admin, create the canonical dev master tenant (matches seeds & UI copy)
    if user_is_super_admin(user):
        default_company = Company.objects.create(
            name="Master Filling Station",
            legal_name="Master Filling Station (Development)",
            currency="BDT",
            is_active=True,
            is_master="true",
        )
        try:
            from api.chart_templates.fuel_station import seed_fuel_station_if_empty

            seed_fuel_station_if_empty(default_company.id, profile="full")
        except Exception as exc:
            logger.warning(
                "Could not seed chart of accounts for master company %s: %s",
                default_company.id,
                exc,
            )
        return default_company.id
    return None
